package com.ood.Views;

/**
 * The view component of the board of the Game LMH, used to show the board
 */
public class LMH_BoardView extends BoardView{
    public LMH_BoardView() {
    }
}
