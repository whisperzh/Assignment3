package com.ood.Views;

import java.util.Scanner;

/**
 * Part of the ood design, the view of main
 */
public class MainView extends View {

}
