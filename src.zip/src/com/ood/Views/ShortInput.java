package com.ood.Views;

import java.util.Scanner;

/**
 * My own input interface
 */
public interface ShortInput {
    Scanner getScanner();
    String jin_Str();
    int jin_Int();
    double jin_double();
}
