package com.ood.Characters;

import java.util.List;

/**
 * monster dragons
 */
public class Dragon extends GeneralMonster{

    public Dragon(List<String> attributes) {
        super(attributes);
    }
}
