package com.ood.Characters;

import com.ood.Item.Spell;

import java.util.List;

/**
 * monster ExoSkeletons
 */
public class ExoSkeleton extends GeneralMonster{


    public ExoSkeleton(List<String> attributes) {
        super(attributes);
    }


}
