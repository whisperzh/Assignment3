package com.ood.Characters;

import java.util.List;

/**
 * monster spirits
 */
public class Spirit extends GeneralMonster{
    public Spirit(List<String> attributes) {
        super(attributes);
    }
}
