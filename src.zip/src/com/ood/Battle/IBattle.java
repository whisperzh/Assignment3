package com.ood.Battle;

/**
 *  Encapsulated all of the battle methods
 */
public interface IBattle {
    void fight();
}
