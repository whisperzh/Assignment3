package com.ood.Team;

import com.ood.Characters.ICharacter;

/**
 *  The concrete class that store characters
 */
public class LMH_CharacterCollection extends SimpleCollection<ICharacter> {
    public LMH_CharacterCollection() {
        super();
    }
}
