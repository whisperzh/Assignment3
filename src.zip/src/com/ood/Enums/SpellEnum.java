package com.ood.Enums;

/**
 * type of spells
 */
public enum SpellEnum {
    ICE,
    FIRE,
    LIGHTNING
}
