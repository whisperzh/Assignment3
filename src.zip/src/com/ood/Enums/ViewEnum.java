package com.ood.Enums;

/**
 * type of views
 */
public enum ViewEnum {
    CONTROLLER,
    MAIN,
    BATTLEFIELD,
    MARKET;
}
