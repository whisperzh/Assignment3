package com.ood.Enums;

/**
 * All of the LMH grid status
 */
public enum LMHGridEnum {
    MARKET,
    OBSTACLE,
    OCCUPIED,
    VACANT
}
