package com.ood.FunctionInterfaces;

/**
 * The Interface of grid content,namely, what object is in the grid
 */
public interface IGridContent {
    boolean isMarket();
    boolean isObstacle();
}
